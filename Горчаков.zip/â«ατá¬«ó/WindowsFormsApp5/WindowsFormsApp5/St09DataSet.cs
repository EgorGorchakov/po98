﻿namespace WindowsFormsApp5
{


    partial class St09DataSet
    {
        partial class PCDataTable
        {
        }
    }
}
